<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/frontend'); ?>
<div id="content">
	<?php echo $content; ?>
</div><!-- content -->
<?php $this->endContent(); ?>